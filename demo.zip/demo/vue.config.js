module.exports={
    runtimeCompiler:true,
    publicPath:'./',
}



